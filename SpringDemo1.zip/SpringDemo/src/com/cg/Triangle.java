package com.cg;

public class Triangle {
	
	private String type;
	private String height;
	
	
	public Triangle() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Triangle(String type, String height) {
		super();
		this.type = type;
		this.height = height;
	}

	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public String getHeight() {
		return height;
	}


	public void setHeight(String height) {
		this.height = height;
	}


	public void draw() {
		System.out.println(type+ " Triangle is drawn with height "+height);

	}

}
