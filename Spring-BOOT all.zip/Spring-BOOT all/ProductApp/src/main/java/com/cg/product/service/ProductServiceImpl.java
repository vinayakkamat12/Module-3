package com.cg.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.beans.Product;
import com.cg.product.dao.ProductRepository;
import com.cg.product.exception.ProductException;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	private ProductRepository productRepository;
	
	@Override
	public List<Product> getAllProducts() throws ProductException{
		try
		{
			return productRepository.findAll();
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}
		
	}

	
	@Override
	public Product getProductById(int id) throws ProductException{
		if(!productRepository.existsById(id))
		{
			throw new ProductException("Product with Id "+id+" doesnot exist");
		}
		return productRepository.findById(id).get();
		
	}

	@Override
	public List<Product> addProduct(Product product) throws ProductException{
		if(productRepository.existsById(product.getId()))
		{
			throw new ProductException("Product with ID " +product.getId()+ " already exists");
		}
		productRepository.save(product);
		
		return productRepository.findAll();
	}


	@Override
	public List<Product> deleteProduct(int id) throws ProductException {
		if(!productRepository.existsById(id))
		{
			throw new ProductException("Product with id "+id+" does not exist.");
		}
		productRepository.deleteById(id);
		return getAllProducts();
	}


	@Override
	public List<Product> updateProduct(Product product, int id) throws ProductException {
		if(productRepository.existsById(product.getId()))
		{
			Product originalProduct=getProductById(id);
			originalProduct.setPrice(product.getPrice());
			originalProduct.setQuantity(product.getQuantity());
			productRepository.save(originalProduct );
			return getAllProducts();
		}
		throw new ProductException("Product does not exists");
		
	}

}
