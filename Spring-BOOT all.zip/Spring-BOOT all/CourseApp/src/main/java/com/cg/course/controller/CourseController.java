package com.cg.course.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.course.beans.Course;
import com.cg.course.exception.CourseException;
import com.cg.course.service.CourseService;

@RestController
public class CourseController {
	
	@Autowired
	private CourseService courseService;
	
	@RequestMapping("/courses")
	public List<Course> getCourses() throws CourseException
	{
		return courseService.getAllCourse();
	}
	
	@PostMapping("/courses")
	public List<Course> addCourse(@RequestBody Course course) throws CourseException
	{
		return courseService.addCourse(course);
	}
	
	@GetMapping("/courses/{courseId}")
	public Course getCourseById(@PathVariable String courseId) throws CourseException
	{
		return courseService.getCourseById(courseId);
	}
	
	@GetMapping("/courses/mode")
	public List<Course> getCourseByMode(@RequestParam("mode") String mode) throws CourseException
	{
		return courseService.getCourseByMode(mode);
	}
	
	@DeleteMapping("/courses/{courseId}")
	public List<Course> deleteCourse(@PathVariable String courseId) throws CourseException
	{
		return courseService.deleteCourse(courseId);
	}
	
	@PutMapping("/courses/update/{courseId}")
	public List<Course> updateCourse(@RequestBody Course course,@PathVariable String courseId) throws CourseException
	{
		return courseService.updateCourse(course, courseId);
	}

}
