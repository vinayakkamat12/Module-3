package com.cg.course.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.course.beans.Course;
import com.cg.course.dao.CourseRepository;
import com.cg.course.exception.CourseException;

@Service
public class CourseServiceImpl implements CourseService{
	
	@Autowired
	private CourseRepository courseRepository;
	
	@Override
	public List<Course> getAllCourse() throws CourseException {
		
		return courseRepository.findAll();
	}

	@Override
	public Course getCourseById(String courseId) throws CourseException {
		if(courseRepository.existsById(courseId))
		{
			return courseRepository.findById(courseId).get();
		}
		throw new CourseException("Course with id "+courseId+" doesnot exist.");
	}

	@Override
	public List<Course> addCourse(Course course) throws CourseException {
		if(courseRepository.existsById(course.getCourseId()))
		{
			throw new CourseException("Course with id "+course.getCourseId()+" already exists");
		}
		courseRepository.save(course);
		return courseRepository.findAll();
	}

	@Override
	public List<Course> deleteCourse(String courseId) throws CourseException {
		if(!courseRepository.existsById(courseId))
		{
			throw new CourseException("Course with id "+courseId+" doesnot exist");
		}
		courseRepository.deleteById(courseId);
		return getAllCourse();
	}

	@Override
	public List<Course> updateCourse(Course course, String courseId) throws CourseException {
		if(courseRepository.existsById(course.getCourseId()))
		{
			Course originalCourse=getCourseById(courseId);
			originalCourse.setDuration(course.getDuration());
			originalCourse.setMode(course.getMode());
			courseRepository.save(originalCourse);
			return getAllCourse();
		}
		throw new CourseException("Course does not exist");
	}

	@Override
	public List<Course> getCourseByMode(String mode) throws CourseException {
//		if(courseRepository.existsById(mode))
//		{
//			return courseRepository.findById(mode).get();
//		}
//		throw new CourseException("Course with mode "+mode+" does not exist.");
		return courseRepository.getMode(mode);
	}
	
	

}
