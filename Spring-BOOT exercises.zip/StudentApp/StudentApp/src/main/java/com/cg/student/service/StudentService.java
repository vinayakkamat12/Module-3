package com.cg.student.service;

import java.util.List;

import com.cg.student.beans.Student;
import com.cg.student.exception.StudentException;

public interface StudentService {
	public List<Student> getAllStudents() throws StudentException;
	public List<Student> addStudent(Student stud) throws StudentException;
	public List<Student> getStudentByStream(String stream) throws StudentException;
	public List<Student> deleteStudent(int id) throws StudentException;
	public List<Student> updateStudent(Student stud) throws StudentException;
}
