package com.cg.student.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.student.beans.Student;
import com.cg.student.dao.StudentRepository;
import com.cg.student.exception.StudentException;

@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	private StudentRepository studentRepository;
	
	@Override
	public List<Student> getAllStudents() throws StudentException {
		
		return studentRepository.findAll();
	}

	@Override
	public List<Student> addStudent(Student stud) throws StudentException {
		if(studentRepository.existsById(stud.getId()))
		{
			throw new StudentException("Student with id "+stud.getId()+" already exists");
		}
		studentRepository.save(stud);
		return studentRepository.findAll();
		
	}
	
	@Override
	public List<Student> getStudentByStream(String stream) throws StudentException {
		return studentRepository.findStudentByStream(stream);
	}

	@Override
	public List<Student> deleteStudent(int id) throws StudentException {
 
		if(!studentRepository.existsById(id))
		{
			throw new StudentException("Student with id "+id+" doesnot exist");
		}
		studentRepository.existsById(id);
		return getAllStudents();
	}

	@Override
	public List<Student> updateStudent(Student stud) throws StudentException {
		if(!studentRepository.existsById(stud.getId()))
		{
		throw new StudentException("Not Found");
		}
		else {
			studentRepository.save(stud);
		}
		 
		return getAllStudents();
	}
	
	
	

}
