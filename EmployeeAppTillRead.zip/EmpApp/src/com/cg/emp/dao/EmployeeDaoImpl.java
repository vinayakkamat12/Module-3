package com.cg.emp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.emp.bean.Employee;
import com.cg.emp.exception.EmployeeException;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		try {
			TypedQuery<Employee> query = entityManager.createQuery("from Employee order by empId", Employee.class);
			List<Employee> employees = query.getResultList();
			return employees;
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}

}
