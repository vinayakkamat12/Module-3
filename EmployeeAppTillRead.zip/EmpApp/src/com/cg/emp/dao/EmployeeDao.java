package com.cg.emp.dao;

import java.util.List;

import com.cg.emp.bean.Employee;
import com.cg.emp.exception.EmployeeException;

public interface EmployeeDao {

	List<Employee> getAllEmployees() throws EmployeeException;	 
}
