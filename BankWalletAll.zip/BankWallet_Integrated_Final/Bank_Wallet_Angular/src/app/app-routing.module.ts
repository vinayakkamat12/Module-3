import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateAccountComponent } from './components/create-account/create-account.component';
import { DepositAmountComponent } from './components/deposit-amount/deposit-amount.component';
import { WithdrawAmountComponent } from './components/withdraw-amount/withdraw-amount.component';
import { ShowBalanceComponent } from './components/show-balance/show-balance.component';
import { ShowTransactionsComponent } from './components/show-transactions/show-transactions.component';
import { FundTransferComponent } from './components/fund-transfer/fund-transfer.component';
import { HomeComponent } from './components/home/home.component';

const routes: Routes = [
  {
    path: 'create',
    component: CreateAccountComponent
  },
  {
    path: 'deposit',
    component: DepositAmountComponent
  },
  {
    path: 'withdraw',
    component: WithdrawAmountComponent
  },
  {
    path: 'transactions',
    component: ShowTransactionsComponent
  },
  {
    path: 'balance',
    component: ShowBalanceComponent
  },
  {
    path: 'fund-transfer',
    component: FundTransferComponent
  }, {
    path: '**',
    component: HomeComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
