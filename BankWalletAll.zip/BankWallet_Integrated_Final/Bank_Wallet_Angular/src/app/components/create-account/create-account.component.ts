import { Component, OnInit } from '@angular/core';
import { WalletService } from '../../services/wallet.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from '../../_helpers/must-match.validator';
import { SampleResponse } from 'src/app/models/SampleResponse.model';
@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent implements OnInit {
  createForm: FormGroup;
  response: SampleResponse;
  constructor(private service: WalletService, private formBuilder: FormBuilder) {
  }
  ngOnInit() {
    this.createForm = this.formBuilder.group({
      name: ['', [Validators.required, Validators.pattern("^[a-zA-Z][a-zA-Z '-.,]{0,31}$|^$"), Validators.minLength(3)]],
      mobile: ['', [Validators.required, Validators.pattern("^[6-9][0-9]{9}$")]],
      dob: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6), Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*_?&])[A-Za-z\\d@$_!%*?&]{6,16}$")]],
      confirmPass: ['', Validators.required]
    }, { validator: MustMatch('password', 'confirmPass') });
  }
  get formControls() { return this.createForm.controls; }
  onSubmit() {
    if (this.createForm.invalid) {
      return;
    }
    let name: string = this.formControls.name.value;
    let mobile: string = this.formControls.mobile.value;
    let dob: string = this.formControls.dob.value;
    let password: string = this.formControls.password.value;
    this.create(name, mobile, dob, password);
  }
  create(name: string, mobile: string, dob: string, password: string) {
    this.service.create(name, mobile, dob, password).then(response => { this.response = response;
    alert("Account created successfully. Account no. is ".concat(this.response.result['account_number']));}
      , err => {
        if (err.success != undefined && err.success == false) {
          this.response = err;
        }
      });
  }
}
