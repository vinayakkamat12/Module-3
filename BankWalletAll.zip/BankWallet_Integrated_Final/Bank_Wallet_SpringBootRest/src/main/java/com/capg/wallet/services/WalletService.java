package com.capg.wallet.services;

import java.util.List;

import com.capg.wallet.beans.Transaction;
import com.capg.wallet.utils.BankWalletException;

public interface WalletService {
	double depositAmount(String accountNum, double amount, String password) throws BankWalletException;

	double withdrawAmount(String accountNum, double amount, String password) throws BankWalletException;

	double fundTransfer(String accountNum, String accountNumTo, double amount, String password)
			throws BankWalletException;

	String createAccount(String name, String mobile, String dob, String password) throws BankWalletException;

	List<Transaction> getTransactions(String accountNum, String password) throws BankWalletException;

	double getBalance(String accountNum, String password) throws BankWalletException;

}
