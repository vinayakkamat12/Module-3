package com.capg.wallet.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

/*
 * Account.java - Class for Account related details.
 */
@Entity
@Table(name = "bank_wallet_account_tab")
public class Account {
	@Id
	@Column(name = "acc_num")
	private String accountNumber;
	@Pattern(regexp = "^[a-zA-Z][a-zA-Z '-.,]{0,31}$", message = "Please enter a valid name (Only alphabets are allowed in name)")
	@Column(name = "acc_name")
	private String name;
	@Pattern(regexp = "^[6-9][0-9]{9}$", message = "Invalid Mobile Number")
	@Column(name = "acc_mobile")
	private String mobile;
	@Column(name = "acc_balance")
	private double balance;
	@Pattern(regexp = "^[0-9]{4}-(1[0-2]|0[1-9])-(3[01]|[12][0-9]|0[1-9])$", message = "Entered date is invalid")
	@Column(name = "acc_dob")
	private String dob;
	@Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*_?&])[A-Za-z\\d@$_!%*?&]{6,16}$", message = "Entered password is invalid (Your password must contain 1 Uppercase, 1 Lowercase, 1 number and the length should be minimum 8 characterds long)")
	@Column(name = "acc_password")
	private String password;

	public Account() {
		super();
	}

	public String getPassword() {
		return password;
	}

	@Override
	public String toString() {
		return "{accountNumber : " + accountNumber + ", name : " + name + ", mobile : " + mobile + ", balance : "
				+ balance + ", dob : " + dob + ", password : " + password + "}";
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

}
