package com.capg.wallet.beans;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/*
 * Account.java - Class for Account related details.
 */
@Entity
@Table(name = "bank_wallet_account_tab")
public class Account {
	@Id
	@Column(name = "acc_num")
	private String accountNumber;
	@Column(name = "acc_name")
	private String name;
	@Column(name = "acc_mobile")
	private String mobile;
	@Column(name = "acc_balance")
	private double balance;
	@Column(name = "acc_dob")
	private String dob;
	@Column(name = "acc_password")
	private String password;
	@OneToMany(mappedBy = "accountFrom",fetch=FetchType.EAGER)
	private List<Transaction> transactions;
	public List<Transaction> getTransactions() {
		return transactions;
	}

	public void addTransactions(Transaction transaction) {
		this.transactions.add(transaction);
		transaction.setAccountFrom(this);
	}

	public Account() {
		super();
		transactions = new ArrayList<Transaction>();
	}

//	public String toString() {
//		return String.format(
//				"Account Details for Account No.\t:\t%d\nCustomer Name\t:\t%s\nMobile\t\t:\t%s\nBalance\t\t:\t%.3f",
//				accountNumber, name, mobile, balance);
//	}

	public String getPassword() {
		return password;
	}

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", name=" + name + ", mobile=" + mobile + ", balance="
				+ balance + ", dob=" + dob + ", password=" + password + ", transactions=" + transactions + "]";
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

}
