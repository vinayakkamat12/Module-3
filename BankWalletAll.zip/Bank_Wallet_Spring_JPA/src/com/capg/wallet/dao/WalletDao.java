package com.capg.wallet.dao;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import com.capg.wallet.beans.Account;
import com.capg.wallet.beans.Transaction;
import com.capg.wallet.utils.BankWalletException;

/*
 * interface for WalletDaoImpl,contains the methods that must be implemented in the child class.
 */
public interface WalletDao {
	String createAccount(Account account) throws ClassNotFoundException, SQLException;

	Account getAccount(String accountNum) throws BankWalletException, ClassNotFoundException, SQLException;

	String createTransaction(Account account,Transaction tran)
			throws ClassNotFoundException, SQLException, ParseException, BankWalletException;

	double depositAmount(String accountNum, double amount, String password)
			throws BankWalletException, ClassNotFoundException, SQLException, ParseException;

	double withdrawAmount(String accountNum, double amount, String password)
			throws BankWalletException, ClassNotFoundException, SQLException, ParseException;

	double fundTransfer(String accountNum, String password,String accountNumTo, double amount)
			throws BankWalletException, ClassNotFoundException, SQLException, ParseException;

	List<Transaction> getTransactions(String accountNum, String password)
			throws BankWalletException, ClassNotFoundException, SQLException, ParseException;

	double getBalance(String accountNum, String password)
			throws BankWalletException, ClassNotFoundException, SQLException;

}
