package com.capg.wallet.services;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.wallet.beans.Account;
import com.capg.wallet.beans.Transaction;
import com.capg.wallet.dao.WalletDao;
import com.capg.wallet.utils.BankWalletException;
import com.capg.wallet.utils.Utils;

/*
 * Implements abstract methods from WalletService Interface.
 */
@Service("walletService")
public class WalletServiceImpl implements WalletService {
	private WalletDao walletDao;

	@Autowired
	public void setWalletDAO(WalletDao walletDao) {
		this.walletDao = walletDao;
	}

	/*
	 * Creates a transaction object with the given details and passes it to
	 * createTransaction() method of WalletDao Interface.
	 */
	private String createTransaction(String accountFrom, String accountTo, double amount, String remark)
			throws ClassNotFoundException, SQLException, ParseException, BankWalletException {
		Transaction tran = new Transaction();
		String uniqueKey = UUID.randomUUID().toString();
		String tranId = uniqueKey.split("-")[0];
		Account account = walletDao.getAccount(accountFrom);
		tran.setAccountFrom(account);
		tran.setAmount(amount);
		tran.setTime(new Date());
		tran.setRemark(remark);
		tran.setId(tranId);
		tran.setAccountTo(accountTo);
		tranId = walletDao.createTransaction(account, tran);
		return tranId;
	}

	/*
	 * creates new account
	 */
	@Override
	public String createAccount(String name, String mobile, String dob, String password)
			throws ClassNotFoundException, SQLException {

		String accountNumber = Utils.randomString(3) + mobile;
		Account account = new Account();
		account.setName(name);
		account.setBalance(0);
		account.setDob(dob);
		account.setMobile(mobile);
		account.setAccountNumber(accountNumber);
		account.setPassword(password);
		walletDao.createAccount(account);
		return accountNumber;
	}

	/*
	 * Deposits the amount into the account.
	 */
	@Override
	public double depositAmount(String accountNum, double amount, String password)
			throws BankWalletException, ClassNotFoundException, SQLException, ParseException {
		double balance = walletDao.depositAmount(accountNum, amount, password);
		createTransaction(accountNum, "NA", amount, "deposit");
		return balance;
	}

	/*
	 * Withdraws the amount from the account.
	 */
	@Override
	public double withdrawAmount(String accountNum, double amount, String password)
			throws BankWalletException, ClassNotFoundException, SQLException, ParseException {
		double balance = walletDao.withdrawAmount(accountNum, amount, password);
		createTransaction(accountNum, "NA", amount, "withdraw");
		return balance;
	}

	/*
	 * Transfers the amount from one account to another.
	 */
	@Override
	public double fundTransfer(String accountNum, String accountNumTo, double amount, String password)
			throws BankWalletException, ClassNotFoundException, SQLException, ParseException {
		if (accountNum.equals(accountNumTo)) {
			throw new BankWalletException("You cannot transfer funds to your own account.");
		}
		double balance = walletDao.fundTransfer(accountNum, password, accountNumTo, amount);
		createTransaction(accountNum, accountNumTo, amount, "fund transfer");
		return balance;
	}

	/*
	 * Prints all the transactions for a particular account
	 */
	@Override
	public List<Transaction> getTransactions(String accountNum, String password)
			throws BankWalletException, ClassNotFoundException, SQLException, ParseException {
		List<Transaction> trans = walletDao.getTransactions(accountNum, password);
		return trans;
	}

	/*
	 * prints current balance in the account
	 */
	@Override
	public double getBalance(String accountNum, String password)
			throws BankWalletException, ClassNotFoundException, SQLException {
		return walletDao.getBalance(accountNum, password);

	}
}
