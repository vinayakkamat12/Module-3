package com.capg.wallet.services;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import com.capg.wallet.beans.Transaction;
import com.capg.wallet.utils.BankWalletException;
public interface WalletService {
	double depositAmount(String accountNum, double amount, String password)
			throws BankWalletException, ClassNotFoundException, SQLException, ParseException;

	double withdrawAmount(String accountNum, double amount, String password)
			throws BankWalletException, ClassNotFoundException, SQLException, ParseException;

	double fundTransfer(String accountNum, String accountNumTo, double amount, String password)
			throws BankWalletException, ClassNotFoundException, SQLException, ParseException;

	String createAccount(String name, String mobile, String dob, String password)
			throws ClassNotFoundException, SQLException;

	List<Transaction> getTransactions(String accountNum, String password)
			throws BankWalletException, ClassNotFoundException, SQLException, ParseException;

	double getBalance(String accountNum, String password)
			throws BankWalletException, ClassNotFoundException, SQLException;

}
