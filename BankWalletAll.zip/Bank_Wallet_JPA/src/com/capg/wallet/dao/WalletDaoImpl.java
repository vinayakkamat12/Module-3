package com.capg.wallet.dao;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import javax.persistence.EntityManager;

import com.capg.wallet.beans.Account;
import com.capg.wallet.beans.Transaction;
import com.capg.wallet.utils.BankWalletException;

public class WalletDaoImpl implements WalletDao {
	private EntityManager entityManager;

	public WalletDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	/*
	 * begins the transaction
	 */
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	/*
	 * commits the transaction
	 */
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	/*
	 * returns all the transactions for a particular account.
	 */
	public List<Transaction> getTransactions(String accountNum, String password)
			throws ClassNotFoundException, SQLException, ParseException, BankWalletException {
		Account account = verifyAccount(accountNum, password);
		List<Transaction> trans = null;
		trans = account.getTransactions();
		return trans;
	}

	/*
	 * Creates a new account.
	 * 
	 * @param account A variable of Account type
	 * 
	 * @return A String Data type
	 */
	@Override
	public String createAccount(Account account) throws ClassNotFoundException, SQLException {
		entityManager.persist(account);
		return account.getAccountNumber();
	}

	/*
	 * Gets the account details.
	 * 
	 * @param accountNum of type String
	 * 
	 * @return An Account data type
	 */
	@Override
	public Account getAccount(String accountNum) throws BankWalletException, ClassNotFoundException, SQLException {
		Account account = null;
		account =  entityManager.find(Account.class, accountNum);
		if (account == null) {
			throw new BankWalletException("No account found for account number " + accountNum);
		}
		return account;
	}

	/*
	 * Creates new Transaction
	 */
	@Override
	public String createTransaction(Account account,Transaction transaction)
			throws ClassNotFoundException, SQLException, ParseException, BankWalletException {
		account.addTransactions(transaction);
		entityManager.persist(transaction);
		entityManager.merge(account);
		return transaction.getId();
	}

	/*
	 * Verifies if the account number and password are correct.
	 */
	private Account verifyAccount(String accountNum, String password)
			throws BankWalletException, ClassNotFoundException, SQLException {
		Account account = getAccount(accountNum);
		if (!account.getPassword().equals(password)) {
			throw new BankWalletException("You have entered an incorrect passoword!");
		}
		return account;

	}

	/*
	 * Deposits the amount into the account.
	 */
	@Override
	public double depositAmount(String accountNum, double amount, String password)
			throws BankWalletException, ClassNotFoundException, SQLException, ParseException {
		if (amount <= 0) {
			throw new BankWalletException("Entered Amount is invalid " + amount);
		}
		Account account = verifyAccount(accountNum, password);
		double newBalance = account.getBalance() + amount;
		account.setBalance(newBalance);
		entityManager.merge(account);
		return newBalance;
	}

	/*
	 * Withdraws the amount from the account.
	 */
	@Override
	public double withdrawAmount(String accountNum, double amount, String password)
			throws BankWalletException, ClassNotFoundException, SQLException, ParseException {
		if (amount <= 0) {
			throw new BankWalletException("Entered Amount is invalid " + amount);
		}
		Account account = verifyAccount(accountNum, password);
		if (amount > account.getBalance()) {
			throw new BankWalletException("You have Insufficient funds in your account.");
		}
		double newBalance = account.getBalance() - amount;
		account.setBalance(newBalance);
		entityManager.merge(account);
		return newBalance;
	}

	/*
	 * Transfers the amount from one account to another.
	 */
	@Override
	public double fundTransfer(String accountNum, String password, String accountTo, double amount)
			throws BankWalletException, ClassNotFoundException, SQLException, ParseException {
		if (amount <= 0) {
			throw new BankWalletException("Entered Amount is invalid " + amount);
		}
		Account account = verifyAccount(accountNum, password);
		Account account_rec = getAccount(accountTo);
		if (amount > account.getBalance()) {
			throw new BankWalletException("You have Insufficient funds in your account.");
		}
		account_rec.setBalance(account_rec.getBalance() + amount);
		account.setBalance(account.getBalance() - amount);
		entityManager.merge(account);
		entityManager.merge(account_rec);
		return account.getBalance();
	}

	@Override
	public double getBalance(String accountNum, String password)
			throws BankWalletException, ClassNotFoundException, SQLException {
		Account account = verifyAccount(accountNum, password);
		return account.getBalance();
	}

}
