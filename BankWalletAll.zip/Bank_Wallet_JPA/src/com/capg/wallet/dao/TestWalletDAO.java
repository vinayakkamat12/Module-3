package com.capg.wallet.dao;

import java.sql.SQLException;
import java.text.ParseException;

import javax.persistence.EntityManager;

import org.junit.Assert;
import org.junit.Test;

import com.capg.wallet.beans.Account;
import com.capg.wallet.utils.BankWalletException;

public class TestWalletDAO {
	private static EntityManager entityManager = JPAUtil.getEntityManager();
	private static WalletDao walletDao;
	static {
		walletDao = new WalletDaoImpl();
		Account account_1 = new Account();
		account_1.setAccountNumber("ABC9876543210");
		account_1.setBalance(1000);
		account_1.setDob("24/01/1998");
		account_1.setMobile("9876543210");
		account_1.setPassword("Qwerty123_1");
		account_1.setName("Test1");
		Account account_2 = new Account();
		account_2.setAccountNumber("ABC9876543211");
		account_2.setBalance(1200);
		account_2.setDob("24/01/1998");
		account_2.setMobile("9876543211");
		account_2.setPassword("Qwerty123_2");
		account_2.setName("Test2");
		entityManager.getTransaction().begin();
		entityManager.persist(account_1);
		entityManager.persist(account_2);
		entityManager.getTransaction().commit();
	}

	@Test
	public void testDepositAmount() {
		double expectedResult = 1120.0;
		double actualResult = 0;
		entityManager.getTransaction().begin();
		try {
			actualResult = walletDao.depositAmount("ABC9876543210", 120, "Qwerty123_1");
		} catch (ClassNotFoundException | BankWalletException | SQLException | ParseException e) {
			// e.printStackTrace();
		}
		Assert.assertEquals(expectedResult, actualResult, 0.001);

		// rollback to old value
		entityManager.getTransaction().rollback();
	}

	@Test
	public void testWithdrawAmount() {
		double expectedResult = 880.0;
		double actualResult = 0;
		entityManager.getTransaction().begin();
		try {

			actualResult = walletDao.withdrawAmount("ABC9876543210", 120, "Qwerty123_1");
		} catch (ClassNotFoundException | BankWalletException | SQLException | ParseException e) {
			// e.printStackTrace();
		}
		Assert.assertEquals(expectedResult, actualResult, 0.001);

		// rollback to old value
		entityManager.getTransaction().rollback();
	}

	@Test
	public void testFundTransfer() {
		double expectedResult = 1700.0;
		entityManager.getTransaction().begin();
		try {
			walletDao.fundTransfer("ABC9876543210", "Qwerty123_1", "ABC9876543211", 500);
		} catch (ClassNotFoundException | BankWalletException | SQLException | ParseException e) {
			// e.printStackTrace();
		}
		double actualResult = entityManager.find(Account.class, "ABC9876543211").getBalance();
		Assert.assertEquals(expectedResult, actualResult, 0.001);

		// rollback to old value
		entityManager.getTransaction().rollback();
	}

	@Test
	public void testGetBalance() {
		double expectedResult = 1200.0;
		double actualResult = 0;
		entityManager.getTransaction().begin();
		try {
			actualResult = walletDao.getBalance("ABC9876543211", "Qwerty123_2");
		} catch (ClassNotFoundException | BankWalletException | SQLException e) {
			// e.printStackTrace();
		}
		Assert.assertEquals(expectedResult, actualResult, 0.001);

		// rollback to old value
		entityManager.getTransaction().rollback();
	}
}
