package org.cg.emp.service;

import java.util.List;

import org.cg.emp.beans.Employee;
import org.cg.emp.dao.EmployeeRepository;
import org.cg.emp.exception.EmployeeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		try {
			return employeeRepository.findAll();
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}

	@Override
	public List<Employee> addEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeRepository.findAll();
	}

	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> deleteEmployee(int id) throws EmployeeException {
		if(employeeRepository.existsById(id))
			{
				throw new EmployeeException("Employee doesnot exist");
			}
			employeeRepository.deleteById(id);
			return getAllEmployees();
	}
	

	@Override
	public List<Employee> updateEmployee(Employee emp) throws EmployeeException {
		if(employeeRepository.existsById(emp.getId()))
		{
			employeeRepository.save(emp);
			return getAllEmployees();
		}
		throw new EmployeeException("Employee does not exist");
	}

	@Override
	public List<Employee> getEmployeeByGender(String gender) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

}
