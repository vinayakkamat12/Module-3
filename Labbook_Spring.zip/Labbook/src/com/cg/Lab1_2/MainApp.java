package com.cg.Lab1_2;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class MainApp {
	
	public static void main(String[] args) {
		Resource r=new ClassPathResource("Spring1_2.xml");
		BeanFactory fac=new XmlBeanFactory(r);
		Employee emp=(Employee)fac.getBean("employeeBean");
		System.out.println(emp.toString());
	}

}
