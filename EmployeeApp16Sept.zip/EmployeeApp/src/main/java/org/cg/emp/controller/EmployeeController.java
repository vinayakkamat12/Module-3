package org.cg.emp.controller;

import java.util.List;

import org.cg.emp.beans.Employee;
import org.cg.emp.exception.EmployeeException;
import org.cg.emp.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@RequestMapping("/employees")
	public List<Employee> getEmployees() throws EmployeeException {
		return employeeService.getAllEmployees();
	}
	
	
}
