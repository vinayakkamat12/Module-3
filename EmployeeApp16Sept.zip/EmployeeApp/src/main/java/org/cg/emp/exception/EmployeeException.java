package org.cg.emp.exception;

public class EmployeeException extends Exception{

	private static final long serialVersionUID = 1L;

	public EmployeeException() {
		super();
	}
	
	public EmployeeException(String msg) {
		super(msg);
	}

}
