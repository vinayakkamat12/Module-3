package com.spring.assignment;

import java.util.List;

public class SBU {
	private String sbuCode;
	private String sbuName;
	private String sbuHead;
	private List<Employee_2> employees;
	
	public String getSbuCode() {
		return sbuCode;
	}
	public void setSbuCode(String sbuCode) {
		this.sbuCode = sbuCode;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public List<Employee_2> getEmployees() {
		return employees;
	}
	public void setEmployees(List<Employee_2> employees) {
		this.employees = employees;
	}
	public Employee_2 searchEmployee(int id)
	{
		for(Employee_2 employee:employees)
		{
			if(employee.getEmployeeId()==id)
			{
				return employee;
			}
		}
		return null;
	}
	@Override
	public String toString() {
		return "SBU Details [sbuCode=" + sbuCode + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead + "]";
	}
	

}
