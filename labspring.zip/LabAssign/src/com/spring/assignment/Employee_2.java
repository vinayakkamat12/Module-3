package com.spring.assignment;

public class Employee_2 {
	private int age;
	private int employeeId;
	private String employeeName;
	private double salary;
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee_2 [age=" + age + ", employeeId=" + employeeId + ", employeeName=" + employeeName + ", salary="
				+ salary + "]";
	}
	
	public String toString1() {
		return "Employee Info: \nEmployee Id 	:" + employeeId+ "\nEmployee Name 	:" + employeeName + "\nEmployee Salary :"
				+ salary;
	}

	
}
