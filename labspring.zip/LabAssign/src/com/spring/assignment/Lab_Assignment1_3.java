package com.spring.assignment;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Lab_Assignment1_3 {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		SBU sbu=(SBU) context.getBean("sbuid");
		System.out.println("SBU DEtails");
		System.out.println("-------------------");
		System.out.println(sbu.toString());
		System.out.println("Employee Details");
		System.out.println("------------------------");
		System.out.println(sbu.getEmployees().toString());

	}

}
